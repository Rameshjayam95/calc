import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class Ash extends Component {

   constructor(){
       super();
       this.state = {
           data: [],
       };
   } //end constructor

  handleChange = value => {
    this.setState({ data:value });
  }
 
   bindDropDowns() {
       var clientName = document.getElementById('clientName').value

       for(var i=0; i < this.state.data.length; i++) {
        var clientName = this.state.data[i].clientName;
       }
   }

   componentWillMount() {
    fetch('https://jsonplaceholder.typicode.com/users', {
        method: 'GET',
        headers: {
            'Accept': 'application/json',
            'Content-type': 'application/json',
        },
        /*body: JSON.stringify({
            username: '{userName}',
            password: '{password}'
        })*/
    }) /*end fetch */
    .then(results => results.json()) 
    .then(data => this.setState({ data: data })   
)

} //end life cycle

    render() {
        console.log(this.state.data);
        return (
            <div>
          <select className="form-control"  onChange={this.handleChange}
                  data={this.state.data}>
          
            {
            
            this.state.data.map((h, i) => 
            (<option key={i} value={h.data}>{h.name}</option>)
            )
            
            }
            
</select>
<select className="form-control"  data={this.state.data}>
 {
            
            this.state.data.map((h, i) => 
            (<option key={i} value={h.data}>{h.address.street}</option>))
            }
</select>

            </div>


        );
      }
}

ReactDOM.render(<Ash />, document.getElementById('root'));